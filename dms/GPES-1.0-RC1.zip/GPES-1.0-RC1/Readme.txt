To install the Domain Message Specification, extract the Domain Message Specification vn.n.n.zip to an appropriate place on your PC.

Run the Index.htm from the root directory. This will provide access all parts of the documentation. All changes are documented in the Change File

Title: General Practice Extraction Service Domain Message Specification

Description: GPES is a centrally managed primary care data extraction service.
 
Group: Interoperability Specifications

Author: Messaging and Modelling Team.

Version: 1.0

status: RC1 

===================================================================
Copyright UK National Health Service

Status:	NHS copyright applied to materials other than those general
	elements of HL7 included in these packages. 

===================================================================
